#ifndef __BMP_DISPLAY_H__
#define __BMP_DISPLAY_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <errno.h>

void * bmp_display(void *arg);

#endif

