#ifndef __TEST_H__
#define __TEST_H__

#include "font.h"
#include <stdio.h>

void *test (void * arg);

#endif