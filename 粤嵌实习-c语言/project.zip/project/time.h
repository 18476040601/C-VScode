#ifndef __TIME_H__
#define __TIME_H__

#include <stdio.h>
#include <time.h>
#include "font.h"
#include <string.h>
#include <unistd.h>



void * time_get(void * arg);

#endif